# Containerised Django Application

## Introduction
In this practise assignment, we will practice how to use a high level programming language to write a
tool that runs in a containerised environment. We will have a web application that
exposes a http endpoint and applies throttling, when the configured rate limit is reached.
It also has a commandline interface (CLI)  tool that interacts with the web application and is able handle any response from it.

## Application structure
´´´
└── app
    ├── dockerised_django
    │   ├── __init__.py
    │   ├── asgi.py
    │   ├── settings.py
    │   ├── urls.py
    │   └── wsgi.py
    ├── manage.py
    └── requirements.txt
´´´

## Setting up the application
´´´ bash
$ mkdir dockerised_django && cd dockerised_django
$ mkdir app && cd app
$ python3.9 -m venv env
$ source env/bin/activate
´´´

## Installing python packages
Python Package needed to run this application is written inside the requirements.txt file.
´´´ bash
$ pip install -r requirements.txt
´´´

## Installing Docker
Docker is a platform as a service product that leverages OS-level virtualisation to
deliver software in packages that are known as containers. The containers are well isolated from
each other and have a unique way of communicating with each other when configured.

### Installation on ubuntu
´´´bash
 $ sudo apt-get update
 $ sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
´´´
 Add Docker's GPG key:

 ´´´bash
 $ curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
 ´´´
 Adding a stable repository

 ´´´bash
 $  echo \
     "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
     $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
 ´´´

Install Docker Engine
´´´bash
$ sudo apt-get update
$ sudo apt-get install docker-ce docker-ce-cli containerd.io
´´´

# The docker file
´´´
FROM python:3.9.6-alpine
WORKDIR /usr/src/app

ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

RUN pip install --upgrade pip
COPY ./requirements.txt .
RUN pip install -r requirements.txt
COPY . .
´´´

## Docker-compose.yaml
´´´
version: '3.8'

services:
  web:
    build: ./app
    command: python manage.py runserver 0.0.0.0:8000
    volumes:
      - ./app/:/usr/src/app/
    ports:
      - 8000:8000
    env_file:
      - ./.env.dev
´´´

## Using Gunicorn
Gurnicorn is a superfast Web server that is used to run python Application by exposing their ports

´´´yaml
version: '3.8'

services:
  web:
    build: ./app
    command: gunicorn dockerised_django.wsgi:application --bind 0.0.0.0:8000
    ports:
      - 8000:8000
    env_file:
      - ./.env.prod
    depends_on:
      - db
  db:
    image: postgres:13.0-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data/
    env_file:
      - ./.env.prod.db
´´´

## Running the application With Nginx instead
Nginx is popularly used to make Reverse proxies and Load Balancers
´´´conf

upstream hello_django {
    server web:8000;
}

server {

    listen 80;

    location / {
        proxy_pass http://hello_django;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $host;
        proxy_redirect off;
    }

}

´´´
## Deploy the application to Kubernetes 
The deployment.yml file is connected to the Docker image created earlier, therefore to deploy the application to the Kubernetes cluster, we use the Docker image. The image will automatically create containers for the application when we deploy the application. In order to  deploy it to a Kubernetes engine; simply execute the comment below in the terminal (after installing kubernetes CLI):

kubectl apply -f deployment.yml

## Minikube and Kubernetes provide a dashboard to visualize the deployment. To see our deployment in that dashboard, execute the command below in your terminal.

minikube dashboard

## We can access the application using the command below:

minikube start service: dockerised_django 


